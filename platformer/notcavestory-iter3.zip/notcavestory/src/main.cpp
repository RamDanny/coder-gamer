#include "raylib.h"
#include "raymath.h"
#include <stdlib.h>

static const int screenWidth = 1080;
static const int screenHeight = 720;

static Vector2 position = {400, 400};
static Vector2 velocity = {5, 0};
static float G = 0.1f;
static bool isjump = false;
static float playerWidth = 50, playerHeight = 100;

static Camera2D camera = { 0 };
static bool camcatchup_x = false,  camcatchup_y = false;
static Vector2 camdiff = {0, 0}, camvel = {8, 8}, camdamp = {0, 0};

static float camMinSpeed = 30;
static float camMinLength = 10;
static float camSpeedFactor = 0.8f;

void sidescroll();
void cameraFollow(float);

int main(void)
{
    // Initialization
    InitWindow(screenWidth, screenHeight, "Not Cave Story");
    SetTargetFPS(60);
    SetExitKey(KEY_NULL);

    camera.target = position;
    camera.offset = (Vector2){ screenWidth/2.0f, screenHeight/2.0f };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;
    
    // Main game loop
    while (!WindowShouldClose())
    {
        //sidescroll();
        cameraFollow(GetFrameTime());

        if (IsKeyPressed(KEY_RIGHT) || IsKeyDown(KEY_RIGHT)) {
            position.x += velocity.x;
        }
        if (IsKeyPressed(KEY_LEFT) || IsKeyDown(KEY_LEFT)) {
            position.x -= velocity.x;
        }
        if (IsKeyPressed(KEY_UP) || IsKeyDown(KEY_UP)) {
            if (!isjump) {
                isjump = true;
                velocity.y = 5;
            }
        }
        if (isjump) {
            velocity.y > -5? velocity.y -= G: velocity.y = -5;
            if (position.y - velocity.y < 400) position.y -= velocity.y;
            else {
                position.y = 500 - playerHeight;
                velocity.y = 0;
                isjump = false;
            }
        }
        // Draw
        BeginDrawing();
            ClearBackground(BLACK);
            BeginMode2D(camera);
            DrawRectangleLines(350, 400, 50, 100, WHITE);
            DrawRectanglePro((Rectangle){position.x, position.y, playerWidth, playerHeight}, (Vector2){0, 0}, 0, WHITE);
            DrawRectangle(-250, 500, 1500, 200, WHITE);
            EndMode2D();
        EndDrawing();
    }

    // De-Initialization
    CloseWindow(); 
    return 0;
}

void sidescroll() {
    if (abs(position.x - camera.target.x) > (0.3*screenWidth)) {
            camcatchup_x = true;
            camdiff.x = position.x - camera.target.x;
        }
        else if (abs(position.y - camera.target.y) > (0.3*screenHeight)) {
            camcatchup_y = true;
            camdiff.y = position.y - camera.target.y;
        }
        if (camcatchup_x) {
            if (camdiff.x > 0) {
                camera.target.x += camvel.x-camdamp.x;
            }
            else if (camdiff.x < 0) {
                camera.target.x -= camvel.x-camdamp.x;
            }
            if ((camdiff.x > 0 && (position.x - camera.target.x) < 0) || (camdiff.x < 0 && (position.x - camera.target.x) > 0) || camdiff.x == 0 || camvel.x-camdamp.x <= velocity.x) {
                camcatchup_x = false;
                camdiff.x = 0;
                camdamp.x = 0;
            }
            else camdiff.x = position.x - camera.target.x;
        }
        else if (camcatchup_y) {
            if (camdiff.y > 0) {
                camera.target.y += camvel.y-camdamp.y;
            }
            else if (camdiff.y < 0) {
                camera.target.y -= camvel.y-camdamp.y;
            }
            if ((camdiff.y > 0 && (position.y - camera.target.y) < 0) || (camdiff.y < 0 && (position.y - camera.target.y) > 0) || camdiff.y == 0) {
                camcatchup_y = false;
                camdiff.y = 0;
                camdamp.y = 0;
            }
            else camdiff.y = position.y - camera.target.y;
        }
}

void cameraFollow(float delta)
{
    Vector2 diff = Vector2Subtract(position, camera.target);
    float length = Vector2Length(diff);
    if (length > camMinLength)
    {
        float speed = fmaxf(camSpeedFactor*length, camMinSpeed);
        camera.target = Vector2Add(camera.target, Vector2Scale(diff, speed*delta/length));
    }
}
