#include "raylib.h"
#include "raymath.h"
#include <stdlib.h>

static const int screenWidth = 1480;
static const int screenHeight = 840;

static Vector2 position = {400, 450};
static Vector2 velocity = {5, 0};
static float ydamp = 0.75;
static float G = 0.1f;
static bool isjump = false;
static float playerWidth = 50, playerHeight = 50;

static Camera2D camera = { 0 };
static float camMinSpeed = 25;
static float camMinLength = 15;

void cameraFollow(float);

int main(void)
{
    // Initialization
    InitWindow(screenWidth, screenHeight, "Not Cave Story");
    SetTargetFPS(60);
    SetExitKey(KEY_NULL);

    camera.target = position;
    camera.offset = (Vector2){ screenWidth/2.0f, screenHeight/2.0f };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;
    
    // Main game loop
    while (!WindowShouldClose())
    {
        cameraFollow(GetFrameTime());

        if (IsKeyPressed(KEY_RIGHT) || IsKeyDown(KEY_RIGHT)) {
            if (isjump) position.x += velocity.x*ydamp;
            else position.x += velocity.x;
        }
        if (IsKeyPressed(KEY_LEFT) || IsKeyDown(KEY_LEFT)) {
            if (isjump) position.x -= velocity.x*ydamp;
            else position.x -= velocity.x;
        }
        if (IsKeyPressed(KEY_UP) || IsKeyDown(KEY_UP)) {
            if (!isjump) {
                isjump = true;
                velocity.y = 5;
            }
        }
        if (isjump) {
            velocity.y > -5? velocity.y -= G: velocity.y = -5;
            if (position.y - velocity.y < 450) position.y -= velocity.y;
            else {
                position.y = 500 - playerHeight;
                velocity.y = 0;
                isjump = false;
            }
        }
        // Draw
        BeginDrawing();
            ClearBackground(BLACK);
            BeginMode2D(camera);
            DrawRectangleLines(350, 400, 50, 100, WHITE);
            DrawRectanglePro((Rectangle){position.x, position.y, playerWidth, playerHeight}, (Vector2){0, 0}, 0, WHITE);
            DrawRectangle(-250, 500, 1500, 200, WHITE);
            EndMode2D();
        EndDrawing();
    }

    // De-Initialization
    CloseWindow(); 
    return 0;
}

void cameraFollow(float delta)
{
    Vector2 diff = Vector2Subtract(position, camera.target);
    float length = Vector2Length(diff);
    if (length > camMinLength)
    {
        float speed = fmaxf(length, camMinSpeed);
        camera.target = Vector2Add(camera.target, Vector2Scale(diff, speed*3*delta/length));
    }
}
